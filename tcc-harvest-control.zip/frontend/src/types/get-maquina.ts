import Maquina from "./maquina";

interface GetMaquina {
    maquinas: Maquina[];
}
export default GetMaquina;