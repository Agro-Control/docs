import { Gestor } from "./gestor";

interface GetGestor {
    gestor: Gestor[];
}
export default GetGestor;