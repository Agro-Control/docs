import Talhao from "./talhao";

interface GetTalhao {
    talhoes: Talhao[];
}
export default GetTalhao;