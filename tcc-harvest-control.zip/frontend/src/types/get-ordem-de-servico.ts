import OrdemDeServico from "./ordem-de-servico";

interface GetOrdemDeServico {
    ordens_servico: OrdemDeServico[];
}
export default GetOrdemDeServico;