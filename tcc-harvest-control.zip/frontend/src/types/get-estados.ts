

interface GetEstados {
    estados: string[];
}
export default GetEstados;