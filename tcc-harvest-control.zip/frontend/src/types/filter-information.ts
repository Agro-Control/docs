interface FilterItem {
    value: string;
}

interface FilterInformation {
    filterItem: FilterItem[];
}

export default FilterInformation;