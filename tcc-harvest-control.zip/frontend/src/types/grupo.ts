interface Grupo {
    id?: number;
    nome: string;
    data_criacao: string;
    status: string;
  }
  
  export default Grupo;