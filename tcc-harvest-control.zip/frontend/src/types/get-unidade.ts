import Unidade from "./unidade";

interface GetUnidade {
    unidades: Unidade[];
}
export default GetUnidade;