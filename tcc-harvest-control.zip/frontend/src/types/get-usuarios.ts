import { UserData } from "./user";

interface GetUsuarios {
    usuarios: UserData[];
}
export default GetUsuarios;