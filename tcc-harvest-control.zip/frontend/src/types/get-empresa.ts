import Empresa from "./empresa";

interface GetEmpresa {
    empresas: Empresa[];
}
export default GetEmpresa;
