import Operador from "./operador";

interface GetOperador {
    operador: Operador[];
}
export default GetOperador;