import Evento from "./evento";

interface GetEventos {
    eventos: Evento[];
}
export default GetEventos;