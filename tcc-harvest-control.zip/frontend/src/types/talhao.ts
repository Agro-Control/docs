interface Talhao {
    id: number | null;
    codigo: string;
    tamanho: string;
    status: string;
    unidade_id: number;
    
}


export default Talhao;