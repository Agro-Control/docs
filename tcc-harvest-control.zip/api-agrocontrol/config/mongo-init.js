db = db.getSiblingDB('agro_control');
db.createCollection('eventos');
db.createCollection('operadores_maquinas');
