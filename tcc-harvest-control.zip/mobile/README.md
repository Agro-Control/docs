# Mobile Agro Control.


💻 A seguir apresentamos a maneira correta de instalar e executar a aplicação Mobile do TCC Agro Control.


### Requisitos

- Expo com SDK 49 (Não pode ser superior), Node.js e um Gerenciador de Pacotes Node, a aplicação usa o npm.

### Como executar a aplicação

Clonando o repositório


1. No GitHub.com, navegue até https://github.com/Agro-Control/mobile.
2. Nas opções acima dos arquivos do repositório selecione Code.
3. Copie o código SSH ou HTTPS.
4. Abra o terminal e execute git clone git@github.com:Agro-Control/mobile.git (ou HTTPS).


Então, execute localmente:

```
npm install
npx expo start --tunnel
Conecte-se ao Aplicativo Expo Go SDK49
```

<p align="center">Desenvolvido com amor pela equipe do TCC Agro Control 🤍</p>
