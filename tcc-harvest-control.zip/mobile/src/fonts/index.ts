export const fonts = {
      roboto: "Roboto_400Regular",
      robotoBold: "Roboto_700Bold",
      baiBold: "BaiJamjuree_700Bold",
  };
  