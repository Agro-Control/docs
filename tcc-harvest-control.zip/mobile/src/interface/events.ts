export type events = "operacao" | "deslocamento" | "manutencao" | "aguardando_transbordo" | "clima" | "abastecimento" | "inicio_ordem_servico" | "troca_turno" | "fim_ordem";
