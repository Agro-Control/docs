interface Token {
    token: string;
}
export default Token