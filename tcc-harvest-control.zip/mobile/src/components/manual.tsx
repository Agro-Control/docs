import React from "react";
import { Image, Text, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { styles } from "./styles";
import Timer from "../../src/components/timer";
import { colors } from "../../src/colors";
import Header from "./header";
import { SimulatorEvent } from "../interface/Event";
import { useRouter } from "expo-router";
import powerButton from "../assets/power.png";

interface EventProps {
  event: string;
  handleEvent: (event: SimulatorEvent) => void;
  resetTimer: boolean;
  setResetTimer: React.Dispatch<React.SetStateAction<boolean>>;
  handleStartSimulator: () => void;
  orderId: number;
  isAutomaticEvent: boolean;
}

export const eventsArray: SimulatorEvent[] = [
  {
    id: 1,
    name: "Abastecimento",
    value: "abastecimento",
    isAutomatic: false,
    maxDuration: 400000,
    minDuration: 200000,
    rpm: 0,
    maxSpeed: 0,
    minSpeed: 0,
  },
  {
    id: 2,
    name: "Aguard. Trans.",
    value: "aguardando_transbordo",
    isAutomatic: false,
    maxDuration: 13000,
    minDuration: 8000,
    rpm: 0,
    maxSpeed: 0,
    minSpeed: 0,
  },

  {
    id: 4,
    name: "Manutenção",
    value: "manutencao",
    isAutomatic: false,
    maxDuration: 160000,
    minDuration: 90000,
    rpm: 0,
    maxSpeed: 0,
    minSpeed: 0,
  },
  {
    id: 5,
    name: "Clima",
    value: "clima",
    isAutomatic: false,
    maxDuration: 60000,
    minDuration: 20000,
    rpm: 0,
    maxSpeed: 0,
    minSpeed: 0,
  },
  {
    id: 3,
    name: "Troca de Turno",
    value: "troca_turno",
    isAutomatic: false,
    maxDuration: 35000,
    minDuration: 15000,
    rpm: 0,
    maxSpeed: 0,
    minSpeed: 0,
  },
  {
    id: 6,
    name: "Operação",
    value: "operacao",
    isAutomatic: true,
    maxDuration: 40000,
    minDuration: 16000,
    rpm: 1500,
    maxSpeed: 5.0,
    minSpeed: 1.5,
  },

  {
    id: 7,
    name: "Transbordo",
    value: "aguardando_transbordo",
    isAutomatic: true,
    maxDuration: 13000,
    minDuration: 8000,
    rpm: 0,
    maxSpeed: 0,
    minSpeed: 0,
  },
  {
    id: 8,
    name: "Deslocamento",
    value: "deslocamento",
    isAutomatic: true,
    maxDuration: 8000,
    minDuration: 4000,
    rpm: 1000,
    maxSpeed: 3.0,
    minSpeed: 1.0,
  },
  {
    id: 10,
    name: "Operação",
    value: "operacao",
    isAutomatic: true,
    maxDuration: 5000,
    minDuration: 1000,
    rpm: 0,
    maxSpeed: 22.0,
    minSpeed: 17.5,
  },
  {
    id: 11,
    name: "Operação",
    value: "operacao",
    isAutomatic: true,
    maxDuration: 22000,
    minDuration: 10000,
    rpm: 4000,
    maxSpeed: 12.0,
    minSpeed: 5.5,
  },
];

const Manual = ({
  orderId,
  event,
  handleEvent,
  resetTimer,
  setResetTimer,
  isAutomaticEvent,
  handleStartSimulator,
}: EventProps) => {
  const { top } = useSafeAreaInsets();
  const router = useRouter();
  return (
    <View style={[styles.eventContainer, { paddingTop: top + 80 }]}>
      <Header />
      <View style={styles.eventTitleContainer}>
        {!isAutomaticEvent && (
          <TouchableOpacity
            onPress={() => {
              handleStartSimulator();
            }}
            style={{
              position: "absolute",
              left: 0,
              top: 12,
              height: 24,
              width: 24,
            }}
          >
            <Image source={powerButton} style={{ height: 24, width: 24 }} />
          </TouchableOpacity>
        )}
        <Text style={styles.eventTitle}>Eventos</Text>
        <Text style={styles.title}>Ordem de Serviço - {orderId}</Text>
      </View>
      <View style={styles.eventButtonContainer}>
        {eventsArray.slice(0, 4).map((event) => (
          <TouchableOpacity
            onPress={() => handleEvent(event)}
            key={event.id}
            style={[
              styles.eventButton,
              {
                backgroundColor: colors.green[400],
              },
            ]}
          >
            <Text style={styles.buttonText}>{event.name}</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity
          onPress={() => {
            handleEvent({
              id: 3,
              name: "Troca de Turno",
              value: "troca_turno",
              isAutomatic: false,
              maxDuration: 35000,
              minDuration: 15000,
              rpm: 0,
              maxSpeed: 0,
              minSpeed: 0,
            });
            router.push("pages/endTurn");
          }}
          style={[
            styles.eventButton,
            {
              backgroundColor: colors.green[400],
            },
          ]}
        >
          <Text style={styles.buttonText}>Trocar Turno</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            handleEvent({
              id: 9,
              name: "Finalizar OS",
              value: "fim_ordem",
              isAutomatic: false,
              maxDuration: 0,
              minDuration: 0,
              rpm: 0,
              maxSpeed: 0,
              minSpeed: 0,
            });
            router.push("pages/endTurn");
          }}
          style={[
            styles.eventButton,
            {
              backgroundColor: colors.green[700],
            },
          ]}
        >
          <Text style={styles.buttonText}>Finalizar OS</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.eventTimerContainer}>
        <Text style={styles.title}>
          Evento {isAutomaticEvent ? "Automatico" : "Manual"}
        </Text>
        <Text style={styles.eventDescription}>{event || "Ocioso"}</Text>
        <Timer
          setShouldResetTimer={setResetTimer}
          shouldResetTimer={resetTimer}
        />
      </View>
    </View>
  );
};
export default Manual;
